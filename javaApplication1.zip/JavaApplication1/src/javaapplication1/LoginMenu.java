/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class LoginMenu extends JFrame implements ActionListener{
    private JTextField username;
    private JTextField password;
    private JButton loginButton;
    private final TTTWebService proxy;
    TTTWebService_Service service;
    
    public LoginMenu(){
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        displayScreen();
    }
    
    public void displayScreen(){
        username = new JTextField();
        password = new JTextField();
        loginButton = new JButton("Login");
        setTitle("Login Screen");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2,2));
        panel.add(username);
        panel.add(new JLabel("Username", JLabel.CENTER));
        panel.add(password);
        panel.add(new JLabel("Password",JLabel.CENTER));
        setLayout(new BorderLayout());
        add(panel, BorderLayout.NORTH);
        add(loginButton,BorderLayout.CENTER);
        loginButton.addActionListener(this);
        setSize(300,125);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int loggedIn = proxy.login(username.getText(), password.getText());

        if(loggedIn == 0 || loggedIn == -1){
            dispose();
            displayScreen();
        }else{
            dispose();
            User store = new User(loggedIn, username.getText());
            OptionsScreen options = new OptionsScreen(store);
        }
    }
    
}
