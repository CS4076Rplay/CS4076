/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class LeaderBoard extends JFrame{
    private final TTTWebService proxy;
    TTTWebService_Service service;
    ArrayList<String> users = new ArrayList<>();
    ArrayList<Integer> wins = new ArrayList<>();
    ArrayList<Integer> losses = new ArrayList<>();
    ArrayList<Integer> draws = new ArrayList<>();
    
    public LeaderBoard(){
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        getValues();
    }
    
    private void getValues(){
        String table;
        table = proxy.leagueTable();
        String[] data = table.split("/n");
        for(String data1 : data){
            String[] store = data1.split(",");
            if(!users.contains(store[1])){
                users.add(store[1]);
                wins.add(0);
                losses.add(0);
                draws.add(0);
            }
            if(!users.contains(store[2])){
                users.add(store[2]);
                wins.add(0);
                losses.add(0);
                draws.add(0);
            }
            
            String gameState = proxy.getGameState(Integer.parseInt(store[0]));
            System.out.print(gameState);
            switch (gameState) {
                case "-1":
                    break;
                case "1":
                    {
                        int index = users.indexOf(store[1]);
                        int val = wins.get(index);
                        wins.set(index , ++val);
                        index = users.indexOf(store[2]);
                        val = losses.get(index);
                        losses.set(index, ++val);
                        break;
                    }
                case "2":
                    {
                        int index = users.indexOf(store[2]);
                        int val = wins.get(index);
                        wins.set(index , ++val);
                        index = users.indexOf(store[1]);
                        val = losses.get(index);
                        losses.set(index, ++val);
                        break;
                    }
                case "3":
                    {
                        int index = users.indexOf(store[2]);
                        int val = draws.get(index);
                        wins.set(index , ++val);
                        index = users.indexOf(store[1]);
                        val = losses.get(index);
                        draws.set(index, ++val);
                        break;
                    }
                default:
                    break;
            }
        }
        displayScreen();
    }
    public void displayScreen(){
        setTitle("leaderBoard");
        setLayout(new GridLayout(users.size() + 1, 4));
        add(new JLabel("Username"));
        add(new JLabel("wins"));
        add(new JLabel("losses"));
        add(new JLabel("draws"));
        for(int i = 0; i < users.size(); i++){
            add(new JLabel(users.get(i)));
            add(new JLabel(""+wins.get(i)));
            add(new JLabel("" + losses.get(i)));
            add(new JLabel(""+draws.get(i)));
        }
        if(!users.isEmpty()){
            setSize(300, 50*users.size());
        }
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
