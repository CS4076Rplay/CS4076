/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class myStats extends JFrame{
    private final TTTWebService proxy;
    TTTWebService_Service service;
    String username;
    int userId;
    String table;
    int wins = 0;
    int losses = 0;
    int draws = 0;
    
    public myStats(int userId,String username){
        this.username = username;
        this.userId = userId;
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        loadGames();
    }
    private void loadGames(){
        table = proxy.showAllMyGames(userId);
        System.out.print(table);
        switch (table) {
            case "ERROR-NOGAMES":
                JOptionPane.showMessageDialog(this, "You haven't played any games");
                break;
            case "ERROR-DB":
                JOptionPane.showMessageDialog(this, "Error connecting to database");
                break;
            default:
                String[] data = table.split("\n");
                for (String data1 : data) {
                    String[] splitted = data1.split(",");
                    String state = proxy.getGameState(Integer.parseInt(splitted[0]));
                    if(state.equals("-1")){
                        
                    }else if(state.equals("1")){
                        if(splitted[1].equals(username))
                            wins++;
                        else
                            losses++;
                    }else if(state.equals("2")){
                        if(splitted[2].equals(username))
                            wins++;
                        else
                            losses++;
                    }else if(state.equals("3"))
                        draws++;
                }   displayScreen();
                break;
        }
    }
    
    private void displayScreen(){
        setTitle("MY STATS");
        JLabel win = new JLabel("wins");
        win.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel loss = new JLabel("losses");
        loss.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel draw = new JLabel("draws");
        draw.setAlignmentX(Component.CENTER_ALIGNMENT);
        setLayout(new GridLayout(2,3));
        add(win);
        add(loss);
        add(draw);
        add(new JLabel(""+wins));
        add(new JLabel(""+losses));
        add(new JLabel(""+draws));
        setSize(300,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
