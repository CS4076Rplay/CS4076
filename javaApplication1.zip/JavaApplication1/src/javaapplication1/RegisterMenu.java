/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class RegisterMenu extends JFrame implements ActionListener{
    private JTextField username;
    private JTextField password;
    private JTextField name;
    private JTextField surname;
    private JButton register;
    private final TTTWebService proxy;
    TTTWebService_Service service;
    
    public RegisterMenu(){
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        displayScreen();
    }
    
    private void displayScreen(){
        username = new JTextField();
        password = new JTextField();
        name = new JTextField();
        surname = new JTextField();
        register = new JButton("Register");
        setTitle("Register Screen");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4,4));
        panel.add(username);
        panel.add(new JLabel("Username", JLabel.CENTER));
        panel.add(password);
        panel.add(new JLabel("Password",JLabel.CENTER));
        panel.add(name);
        panel.add(new JLabel("Name", JLabel.CENTER));
        panel.add(surname);
        panel.add(new JLabel("Surname", JLabel.CENTER));
        setLayout(new BorderLayout());
        add(panel, BorderLayout.NORTH);
        add(register,BorderLayout.CENTER);
        register.addActionListener(this);
        setSize(300,150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //System.out.print("" + username.getText() + password.getText() + name.getText() + surname.getText());
        String registered = proxy.register(username.getText(), password.getText(), name.getText(), surname.getText());
        Integer.parseInt(registered);
        if(registered.equals("ERROR-REPEAT")){
            JOptionPane.showMessageDialog(this, "User already exists", "Error", JOptionPane.ERROR_MESSAGE);
        }else if(registered.equals("ERROR-INSERT")){
            JOptionPane.showMessageDialog(this, "Unable to add data","Error", JOptionPane.ERROR_MESSAGE);
        }else if(registered.equals("ERROR-RETRIEVE")){
            
        }else if(registered.equals("ERROR-DB")){
            
        }else{
            int reg = Integer.parseInt(registered);
            User user = new User(reg, username.getText());
            OptionsScreen op = new OptionsScreen(user);
        }
    }
    
}
