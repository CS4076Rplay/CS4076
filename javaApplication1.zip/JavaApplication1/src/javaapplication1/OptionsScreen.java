/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Proxy;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class OptionsScreen extends JFrame implements ActionListener{
    JButton[] buttons;
    private User user;
    
    private final TTTWebService proxy;
    TTTWebService_Service service;
    public OptionsScreen(User user){
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        this.user = user;
        displayScreen();
    }

    private void displayScreen() {
        setTitle("Main Screen");
        buttons = new JButton[4];
        buttons[0] = new JButton("My ");
        buttons[1] = new JButton("Leaderboard");
        buttons[2] = new JButton("New Game");
        buttons[3] = new JButton("Show Games");
        buttons[0].addActionListener(this);
        buttons[1].addActionListener(this);
        buttons[2].addActionListener(this);
        buttons[3].addActionListener(this);
        setLayout(new GridBagLayout());
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        buttons[0].setAlignmentX(Component.CENTER_ALIGNMENT);
        buttons[1].setAlignmentX(Component.CENTER_ALIGNMENT);
        buttons[2].setAlignmentX(Component.CENTER_ALIGNMENT);
        buttons[3].setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(buttons[0]);
        panel.add(Box.createRigidArea(new Dimension(0,25)));
        panel.add(buttons[1]);
        panel.add(Box.createRigidArea(new Dimension(0,25)));
        panel.add(buttons[2]);
        panel.add(Box.createRigidArea(new Dimension(0,25)));
        panel.add(buttons[3]);
        add(panel);
        setSize(300,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
        
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if(source == buttons[0]){
            myStats stats = new myStats(user.getUserId(),user.getUsername());
        }else if(source == buttons[1]){
            LeaderBoard board = new LeaderBoard();
        }else if(source == buttons[2]){
            String newGame = proxy.newGame(user.getUserId());
            if(newGame.equals("ERROR-NOTFOUND")){
                
            }else if(newGame.equals("ERROR-RETRIEVE")){
                
            }else if(newGame.equals("ERROR-INSERT")){
                
            }else if(newGame.equals("ERROR-DB")){
                
            }else{
                GameScreen game = new GameScreen(newGame,user.getUserId());
            }
                
        }else if(source == buttons[3]){
            showOpenGames openGames = new showOpenGames(user);
        }
    }
    
}
