/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;

import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class MainScreen extends JFrame implements ActionListener {
    private JButton[] buttons;
    
    public MainScreen(){
        displayScreen();
    }
    
    public void displayScreen(){
        setTitle("Main Screen");
        buttons = new JButton[2];
        buttons[0] = new JButton("Login");
        buttons[1] = new JButton("Register");
        buttons[0].addActionListener(this);
        buttons[1].addActionListener(this);
        setLayout(new GridBagLayout());
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        buttons[0].setAlignmentX(Component.CENTER_ALIGNMENT);
        buttons[1].setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(buttons[0]);
        panel.add(Box.createRigidArea(new Dimension(0,25)));
        panel.add(buttons[1]);
        add(panel);
        setSize(300,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source == buttons[0]){
            LoginMenu login = new LoginMenu();
            dispose();
        }
        else if(source == buttons[1]) {
            RegisterMenu register = new RegisterMenu();
            dispose();
        }
    }
}
