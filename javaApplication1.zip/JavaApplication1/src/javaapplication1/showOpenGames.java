/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class showOpenGames extends JFrame{
     private User user;
    private Object[][] object;
    private TTTWebService proxy;
    TTTWebService_Service service;
    Object[][] data;
    public showOpenGames(User user){
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        this.user = user;
        loadData();
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                createAndShowGUI();
            }
        });
    }
    
    private void createAndShowGUI(){
        String[] columnNames = {"GameId","username","Date Started"};
        final Class[] columnClass = new Class[]{
            String.class,String.class,String.class,String.class
        };

        
        JTable table = new JTable(data,columnNames);
        ListSelectionModel model = table.getSelectionModel();
        model.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                 if(!e.getValueIsAdjusting()){
                     String error = proxy.joinGame(user.getUserId(),Integer.parseInt(table.getValueAt(table.getSelectedRow(), 0).toString()));
                     GameScreen game = new GameScreen(table.getValueAt(table.getSelectedRow(), 0).toString(), user.getUserId());
                 }
            }
        });
        
        this.add(new JScrollPane(table));
        
        this.setTitle("open games");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        this.pack();
        this.setVisible(true);
    }
        
    public void loadData(){
        String list = proxy.showOpenGames();
        String[] games = list.split("\n");
        this.data = new Object[games.length][3];
        for(int i = 0; i < games.length ;i++){
            String[] inside = games[i].split(",");
            for(int j = 0; j < 3;j++){
                this.data[i][j] = inside[j];
            }
        }
    }
    
}
