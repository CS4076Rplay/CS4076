/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.AWTEventMulticaster;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.file.attribute.UserDefinedFileAttributeView;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import jdk.nashorn.internal.parser.TokenType;
import ttt.james.server.SetGameState;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author mitta
 */
public class GameScreen extends JFrame implements Runnable{
    private final TTTWebService proxy;
    TTTWebService_Service service;
    private int gameID;
    private int currentPlayer;
    private int Player;
    static int opponentId;
    private char myToken;
    private char otherToken;
    private int user1 = 0; //store the creator
    private int user2 = 0; //store the opponent
    private int userID;
    private int rowSelected;
    private int columnSelected;
    private Cell[][] cell = new Cell[3][3];
    private boolean token = true;
    private JLabel title = new JLabel();
    private JLabel status = new JLabel();
    private boolean myTurn = false;
    private boolean waiting = true;
    private boolean continueToPlay = true;
    int count = 0;
    
    
    public GameScreen(String game, int userID){
        this.userID = userID;
        this.gameID = Integer.parseInt(game);
        service  = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        displayScreen();
    }
    
    public void displayScreen(){
        newGame();
        String state = proxy.getGameState(gameID);
        if(state.equals("-1")){
            state = proxy.getGameState(gameID);
            user1 = userID;
            currentPlayer = userID;
            status.setText("Waiting for player 2 to join");
        }
        Thread thread = new Thread(this);
        thread.start();
        
    }
    
    public void newGame(){
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3,3));
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++){
                p.add(cell[i][j] = new Cell(i,j));
            }
        }
        p.setBorder(new LineBorder(Color.black, 1));
        title.setHorizontalAlignment(JLabel.CENTER);
        
        add(title, BorderLayout.NORTH);
        add(p, BorderLayout.CENTER);
        add(status,BorderLayout.SOUTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void run() {
        try{
            loadDataFromService();
            if(userID == user1){
                myToken = 'X';
                otherToken = 'O';
                title.setText("Player 1 with token X");
            }else{
                title.setText("Player 2 with token O");
                myToken = 'O';
                otherToken = 'X';
            }
            
            while(continueToPlay){
                loadDataFromService();
                if(userID == user1 && currentPlayer != user1){
                    waitForPlayer();
                    sendMove();

                }else if(userID == user2 && currentPlayer != user2){
                    waitForPlayer();
                    sendMove();
                }
            }
        }catch(Exception ex){
        }
    }
    private void waitForPlayer() throws InterruptedException{
        while(waiting){
            Thread.sleep(100);
        }
        waiting = true;
    }
    
    private void sendMove(){
        String error = proxy.takeSquare(rowSelected, columnSelected, gameID, currentPlayer);
        checkGameStatus();
    }
    
    private void checkGameStatus(){
        String state = proxy.getGameState(gameID);
        if(state.equals("1"))
        {
            if(userID == user1){
               JOptionPane.showMessageDialog(this, "You won(X)");
            }else
                JOptionPane.showMessageDialog(this, "You Lose(O)");
            String error = proxy.setGameState(gameID,Integer.parseInt(state));
        }else if(state.equals("2")){
            if(userID == user1){
               JOptionPane.showMessageDialog(this, "You Lose(X)");
            }else
                JOptionPane.showMessageDialog(this, "You Won(O)");
            String error = proxy.setGameState(gameID,Integer.parseInt(state));
        }else
            JOptionPane.showMessageDialog(this, "it's a draw");
            String error = proxy.setGameState(gameID,Integer.parseInt(state));
        }
    
    public void loadDataFromService(){
        String game = proxy.getBoard(gameID);
        if(game.equals("ERROR-NOMOVES")){
            status.setText("no one has played yet");
        }else if(game.equals("ERROR-DB")){
            status.setText("error connecting to database");
        }else{
            updateScreen(game);
        }
    }
    
    public void updateScreen(String game){
        String[] moves = game.split("\n");
        int f = 0;
        for(int i =0; i < moves.length; i++){
            String[] movesByUser = moves[i].split(",");
            if(user1 == 0){
               user1 = Integer.parseInt(movesByUser[0]);
            }
            if(!(user1 == Integer.parseInt(movesByUser[0]))){
                user2 = Integer.parseInt(movesByUser[0]);
            }
            currentPlayer = Integer.parseInt(movesByUser[0]);
            cell[Integer.parseInt(movesByUser[1])][Integer.parseInt(movesByUser[2])].setToken(myToken);
            count++;
            if(myToken == 'X'){
                myToken = 'O';
                otherToken = 'X';
            }
            else
            {
                myToken = 'X';
                otherToken='O';
            }
        }    
    }
    
    public class Cell extends JPanel{
        private int row;
        private int column;
        
        private char tok = ' ';
        
        public Cell(int row, int column){
            this.row = row;
            this.column = column;
            setBorder(new LineBorder(Color.black, 1));
            addMouseListener(new ClickListener());
        }
        
        public char getToken(){
            return tok;
        }
        
        public void setToken(char c){
            tok = c;
            repaint();
        }
    
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
        
            if(tok == 'X'){
                g.drawLine(10,10, getWidth() - 10, getHeight() - 10);
                g.drawLine(getWidth() - 10, 10, 10, getHeight()- 10);
            }else if(tok == 'O'){
                g.drawOval(10, 10, getWidth() - 20, getHeight() - 20);
            }
        }
    
        private class ClickListener extends MouseAdapter {
            @Override
            public void mouseClicked(MouseEvent e){
                if(tok == ' ' && currentPlayer == userID){
                    setToken(myToken);
                    rowSelected = row;
                    columnSelected = column;
                    status.setText("Waiting for the other player to move");
                    waiting = false;
                }
            }
        }
    }
}
